﻿using System.Web.UI;

namespace WebApplication12.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}